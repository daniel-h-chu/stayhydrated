To use the StayHydrated Application on Android:

	- Download the file 'StayHydrated.aia'
	- Go to 'ai2.appinventor.mit.edu'
	- Under the Projects tab, Import project from your computer
	- Download the application 'MIT App Inventor Companion' onto your Android device
	- Under Build, press 'App(provide QR code for apk)'
	- Scan the QR code in the Companion app
	- Allow the app to download the project files and let it run